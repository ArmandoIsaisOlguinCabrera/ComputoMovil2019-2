import UIKit

let age = 23
let months = 7
let firstName = "Armando"
let lastName = "Olguin"
let birthday = Date(timeIntervalSinceNow: 3600)
let isHappy = true
//buscar anotacion de tipo
//buscar inferencia de tipo



//-> la flecha significa que la funcion devuelve algo

func hello(name nombre:String) -> String { //anotacion de tipo: los dos puntos // con el guion bajo se puede ignorar la etiqueta en la llamada de la funcion
    
    let saludo: String = "Hola" + nombre
    return saludo
    //print("hola " + nombre) //concatenando
    //print("hola", nombre + lastName)
    //print("hola \(nombre)") //interpolacion
}

let saludo: String = hello(name:"pablo")
print (birthday)


/*
 func fibonacci(num: Int) -> Int{
    if num < 2 {
        return num
    }
    else{
        return fibonacci(num: num - 1) + fibonacci(num: num - 2)
    }
}

print(fibonacci(num: 199))

 */
